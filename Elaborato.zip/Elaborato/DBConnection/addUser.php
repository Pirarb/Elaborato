<?php
function addUser(array $user) {
    INCLUDE "connection.php";

    $stmt = $conn->prepare("INSERT INTO utenti (username, password, mail, sesso, anno, residenza) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt-> bind_param("ssssii", $username, $password, $mail, $sesso, $anno, $comuni);

    $username = $user["username"];
    $password = hash("sha256",$user["password"]);
    $mail = $user["mail"];
    $sesso = $user["sesso"];
    $anno = $user["anno"];
    $comuni = $user["comuni"];
    $stmt->execute();
}


addUser($_POST);
header("Location: ../Prova/");
?>

