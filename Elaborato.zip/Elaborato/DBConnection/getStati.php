<?php
    function getStati($id_utente) {
        INCLUDE "connection.php";

        $sql = 'SELECT st.id_utente, st.ora, st.positivo, 
        GROUP_CONCAT(si.nome SEPARATOR "<br>") AS sintomi, q.parametri
        FROM stati AS st
        LEFT JOIN stati_sintomi AS stsi
            ON stsi.ora = st.ora AND stsi.id_utente = st.id_utente
        LEFT JOIN sintomi AS si
            ON stsi.id_sintomo = si.id
        INNER JOIN(
                SELECT st.id_utente, st.ora, 
                GROUP_CONCAT(pa.nome, ": ", stpa.misura, " ", pa.unita SEPARATOR "<br>") AS parametri
                FROM stati AS st
                LEFT JOIN stati_parametri AS stpa
                    ON stpa.ora = st.ora AND stpa.id_utente = st.id_utente
                LEFT JOIN parametri AS pa
                    ON stpa.id_parametro = pa.id
                GROUP BY st.ora
            ) AS q
            ON q.ora = st.ora AND q.id_utente = st.id_utente
        WHERE st.id_utente = ?
        GROUP BY st.ora;';

        $stmt = $conn->prepare($sql);
        $stmt-> bind_param("i", $id_utente);
        $stmt-> execute();
        $result = $stmt->get_result();

        echo "<table id='tables'> <tr> <th> Ora </th> <th> Stato </th> <th> Sintomi </th> <th> Misure </th> </tr> ";
        if(!empty($result) && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr> <td> " . $row["ora"] . "</td>";
                if($row["positivo"] === 0) {
                    echo "<td> Negativo </td>"; 
                } else {
                    echo "<td> Positivo </td>";
                }

                echo "<td> " . $row["sintomi"] . " </td> <td> " . $row["parametri"] . "</td></tr>";
            }
        }
        echo "</table>";

    }
?>
