<?php
$servername = "localhost";
$usrnm = "root";             //$usrnm = username
$pss = "";                  //$pss = password
$dbname = "Elaborato";      //nome del nostro database


//create connection
$conn = new mysqli($servername, $usrnm, $pss, $dbname);

//check connection
if($conn->connect_error)
{
    die("Connection faild: ".$conn->connect_error);
}

?>