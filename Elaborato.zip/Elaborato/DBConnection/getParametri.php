<?php
    function getParametri() {
        INCLUDE "connection.php";
        $result = $conn->query("SELECT * FROM parametri");

        if(!empty($result) && $result->num_rows > 0){
            echo "<table style='color:white;'>";
            while($row = $result->fetch_assoc()) {
                echo '<tr><th style="text-align:left;"> <label for="parametro'. $row["id"] .'"> '. $row["nome"] .': </label> </th>';
                echo '<td> <input type="number" id="parametro'. $row["id"] .'" name="parametri['. $row["id"] .']" step="0.1" value="'. $row["norma"] .'"> </td>';
                echo '<td> <label for="parametro'. $row["id"] .'"> '. $row["unita"] .' </label> </td> </tr>';
            }
            echo "</table>";
        }
    }
?>
