<?php
    function getParametri() {
        INCLUDE "connection.php";
        $result = $conn->query("SELECT * FROM parametri");

        if(!empty($result) && $result->num_rows > 0){
            while($row = $result->fetch_assoc()) {
                echo '<label for="parametro'. $row["id"] .'"> '. $row["nome"] .' </label>';
                echo '<input type="number" id="parametro'. $row["id"] .'" name="parametri['. $row["id"] .']" step="0.1" value="'. $row["norma"] .'"> ';
                echo '<label for="parametro'. $row["id"] .'"> '. $row["unita"] .' </label> <br>';
            }
        }
    }
?>
