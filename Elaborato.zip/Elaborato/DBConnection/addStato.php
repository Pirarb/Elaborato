<?php
session_start();
INCLUDE "connection.php";
$stmt = $conn->prepare("INSERT INTO stati VALUES (?, ?, ?);");
$stmt-> bind_param("sii", $dateTime, $id_utente, $positivita);
$dateTime = date("Y-m-d H:i:s");
$id_utente = $_SESSION["id"];
$positivita = $_POST["positivita"];
$stmt-> execute();

if(isset($_POST["parametri"])) {
    $keys = array_keys($_POST["parametri"]);
    $stmt2 = $conn->prepare("INSERT INTO stati_parametri VALUES(?, ?, ?, ?)");
    $stmt2-> bind_param("isid", $id_parametro, $dateTime, $id_utente, $misura);
    $i = 0;
    foreach($_POST["parametri"] as $misurazione) {
        $id_parametro = $keys[$i];
        $misura = $misurazione;
        $i += 1;
        $stmt2 -> execute();
    }
}


if(isset($_POST["sintomi"])) {
    $stmt3 = $conn->prepare("INSERT INTO stati_sintomi VALUES (?,?,?)");
    $stmt3 -> bind_param("isi", $id_sintomo, $dateTime, $id_utente);
    foreach($_POST["sintomi"] as $sintomo) {
        $id_sintomo = $sintomo;
        $stmt3 -> execute();
    }
}

header("Location: ../Prova/Riservato/welcome.php");
?>