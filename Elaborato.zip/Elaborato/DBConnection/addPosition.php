<?php
session_start();
if(!isset($_SESSION["id"]) || !isset($_GET["lat"]) || !isset($_GET["lng"])) {
    header("Location: ../Prova/index.php");
}

INCLUDE "connection.php";
$stmt = $conn->prepare("INSERT INTO posizioni VALUES (?,?,?,?)");
$stmt -> bind_param("isdd", $id, $ora, $latitudine, $longitudine);
$id = $_SESSION["id"];
$ora = date("Y-m-d H:i:s");
$latitudine = $_GET["lat"];
$longitudine = $_GET["lng"];
$stmt -> execute();
header("Location: ../Prova/Riservato/showPositions.php");
?>