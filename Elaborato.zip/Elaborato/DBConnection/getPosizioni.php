<?php
function getPosizioni($id_utente) {
    INCLUDE "connection.php";
    $sql = "SELECT *
    FROM posizioni
    WHERE id_utente = ?
    ORDER BY ora";
    $stmt = $conn-> prepare($sql);
    $stmt-> bind_param("i", $id_utente);
    $stmt-> execute();
    $result = $stmt->get_result();

    echo "<table> <tr> <th> Ora </th> <th> Latitudine </th> <th> Longitudine </th> </tr>";
    if(!empty($result) && $result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "<tr> <td> " . $row["ora"] . "</td> <td> " . $row["latitudine"] . " </td> <td> " . $row["longitudine"] . " </td> </tr>";
        }
    }
    echo "</table>";
}
?>

