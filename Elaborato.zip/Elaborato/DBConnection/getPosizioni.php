<?php
function getPosizioni($id_utente) {
    INCLUDE "connection.php";
    $sql = "SELECT *
    FROM posizioni
    WHERE id_utente = ?
    ORDER BY ora";
    $stmt = $conn-> prepare($sql);
    $stmt-> bind_param("i", $id_utente);
    $stmt-> execute();
    $result = $stmt->get_result();

    echo "<table id='tables'> <tr> <th> Ora </th> <th> Latitudine </th> <th> Longitudine </th> </tr>";
    if(!empty($result) && $result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "<tr> <td> " . $row["ora"] . "</td> <td> " . $row["latitudine"] . " </td> <td> " . $row["longitudine"] . " </td> </tr>";
        }
    }
    echo "</table>";
}

function getMarker($id_utente) {
    INCLUDE "connection.php";
    $sql = "SELECT *
    FROM posizioni
    WHERE id_utente = ?
    ORDER BY ora";
    $stmt = $conn-> prepare($sql);
    $stmt-> bind_param("i", $id_utente);
    $stmt-> execute();
    $result = $stmt->get_result();

    if(!empty($result) && $result->num_rows > 0) {
        $i = 0;
        
        while($row = $result->fetch_assoc()) {
            echo "var marker".$i ." = L.marker([". $row["latitudine"] .",". $row["longitudine"] ."]).addTo(map);\n"; 
            echo "marker".$i . ".bindPopup('<b>". $row["ora"] ."</b><br>Latitudine: ".$row["latitudine"]."<br>Longitudine: ". $row["longitudine"] ."');\n";
            if($i != 0) {
                echo "var polygon".$i." = L.polygon([[".$previusLat.",".$previusLon."],[".$row["latitudine"].",".$row["longitudine"]."]]).addTo(map);\n";
            }
            $previusLat = $row["latitudine"];
            $previusLon = $row["longitudine"];
            $i++;
        }

        echo "map.setView([".$previusLat.",".$previusLon."], 15);";
    } else {
        echo "map.setView([45,8], 7);";
    }
}
?>

