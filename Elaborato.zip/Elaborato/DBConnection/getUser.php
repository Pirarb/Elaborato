<?php
    function getUser($username) {
        INCLUDE "connection.php";

        $sql = "SELECT u.username, u.mail, u.sesso, c.nome AS comune, p.nome AS provincia
        FROM utenti AS u
        INNER JOIN comuni AS c
            ON u.residenza = c.id
        INNER JOIN province AS p
            ON c.id_provincia = p.id
        WHERE u.username = ?";

        $stmt = $conn->prepare($sql);
        $stmt-> bind_param("s", $username);
        $stmt-> execute();
        
        $result = $stmt-> get_result();
        if(!empty($result) && $result->num_rows > 0){
            echo "<table> <tr> <th> Username </th> <th> Mail </th> <th> Sesso </th> <th> Comune </th> <th> Provincia </th> </tr>";
            while($row = $result->fetch_assoc()) {
                switch ($row["sesso"]) {
                    case 'm': { $sesso = "maschio"; break; }

                    case 'f': { $sesso = "femmina"; break; }

                    default: { $sesso = "altro"; break; }
                }
                echo "<tr> <td> ". $row["username"] ." </td> <td> ". $row["mail"] ." </td> <td> ". $sesso ." </td> <td> ". $row["comune"] ." </td> <td> ". $row["provincia"] ." </td> </tr>";
            }
            echo "</table>";
        }
    }
?>
