<?php
function getProvince() {
    INCLUDE "connection.php";
    $result = $conn->query("SELECT * FROM province");
    //print_r($result);
    if(!empty($result) && $result->num_rows > 0){
        echo "<select name='province' id=\"province\" onChange='getComuni()' required>";
        while($row = $result->fetch_assoc()) {
            echo '<option value="' . $row["id"] . '">'. $row["nome"] .'</option>';
        }

        echo "</select>";
    }
}
?>

<script src="../Script/getComuni.js">
</script> 
