<?php
    function controlloData($id_utente) {
        INCLUDE "connection.php";
        $stmt = $conn-> prepare("SELECT * FROM stati WHERE id_utente=? AND DATE(ora) = ( SELECT DATE(MAX(ora)) FROM stati WHERE id_utente = ? ) AND DATE(ora) = ?;");
        $stmt-> bind_param("iis", $id_utente, $id_utente, $data);
        $data = date("Y-m-d");
        $stmt-> execute();
        
        $result = $stmt-> get_result();
        if(!empty($result)){
            switch ($result->num_rows) {
                case 0: {                  
                    return true;
                    break;
                }

                case 1: {
                    $row = $result->fetch_assoc();  
                    if($row["positivo"] == 0) {
                        return false;
                    } else {
                        return true;
                    }
                    break;
                }

                default: {
                    return false;
                    break;
                }
            }
        } 

        return false;
    }
?>
