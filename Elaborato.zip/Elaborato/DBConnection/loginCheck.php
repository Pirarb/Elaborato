<?php
    INCLUDE "connection.php";
    $stmt = $conn->prepare("SELECT password, sesso, id FROM utenti WHERE username = ?");
    $stmt-> bind_param("s", $_POST["username"]);
    $stmt-> execute();
    $result = $stmt->get_result();


    if(!empty($result) && $result->num_rows > 0){
        while($row = $result->fetch_assoc()) {
            //print_r($row);
            if(hash("sha256",$_POST["password"]) == $row["password"]) {
                successo($row["sesso"], $row["id"]);
            }
            else {
                errore();
            }
        }
    } else {
        errore();
    }

    function errore() {
        session_start();
        $_SESSION["error"] = True;
        $_SESSION["errorUsername"] = $_POST["username"];
        header("Location: ../Prova/login.php");
    }

    function successo($sesso, $id) {
        session_start();
        $_SESSION["username"] = $_POST["username"];
        $_SESSION["sesso"] = $sesso;
        $_SESSION["id"] = $id;
        header("Location: ../Prova/Riservato/welcome.php");
    }
?>
