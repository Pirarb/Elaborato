<?php
INCLUDE "../DBConnection/connection.php";
$sql = "SELECT * FROM comuni WHERE id_provincia=?;";

$stmt = $conn->prepare($sql);

if(isset($_GET["id_provincia"]))
    $stmt->bind_param("i",$_GET["id_provincia"]);
else
    $stmt->bind_param("i",1);

$stmt->execute();
$result = $stmt->get_result();

if(!empty($result) && $result->num_rows > 0){
    //echo "<select name='comuni' id=\"comuni\" required>";
    while($row = $result->fetch_assoc()) {
        echo '<option value="' . $row["id"] . '">'. $row["nome"] .'</option>';
    }

    //echo "</select>";
}
?>
