<?php
INCLUDE "../DBConnection/connection.php";
$sql = "SELECT username FROM utenti";
$result = $conn->query($sql);

if (!empty($result) && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        if($row["username"] == $_GET["username"]) {
            echo "Username già preso";
            break;
        }
    }
}
//echo $_GET["username"];
if(strlen($_GET["username"])<8 /*&& strlen($_GET["username"])!=0*/) {
    echo "L'username deve essere lungo almeno 8 caratteri";
}
echo "";
$conn->close();
?>
