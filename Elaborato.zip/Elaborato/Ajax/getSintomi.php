<?php
INCLUDE "../DBConnection/connection.php";
$sql = "SELECT * FROM sintomi";
$result = $conn->query($sql);
if(!empty($result) && $result->num_rows > 0) {
    echo "<h1> Sintomi </h1>";
    while($row = $result->fetch_assoc()) {
        echo "<input type='checkbox' id='sintomo". $row["id"] ."' name='sintomi[]' value='". $row["id"] ."'>";
        echo "<label for='sintomo". $row["id"] ."'> ". $row["nome"] ." </label> <br>";
    }
}
$conn->close();
?>
