<?php
if(strlen($_GET["password"]) < 8) {
    echo "La password deve essere lunga almeno 8 caratteri";
}

echo "";
?>
