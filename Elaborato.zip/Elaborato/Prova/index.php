<?php
session_start();
session_unset();
session_destroy();
?>
<head>
    <link rel="stylesheet" type="text/css" href="../Style/index.css">
</head>

<body>
    <div id="container">
        <h1> Benvenut* </h1>

        <div id="buttons">
            <a href="login.php"> LOGIN </a>

            <a href="register.php"> REGISTRATI </a>
        </div id="buttons">
    </div>
</body>
