<?php
    session_start();
?>
<head>
    <script src="../Script/changeVisibility.js">
    </script>

    <script>
        function removeError() {
            document.getElementById("error").remove();
            document.getElementById("username").onkeydown = "";
        }
    </script>

    <link rel="stylesheet" type="text/css" href="../Style/forms.css">
</head>

<body>
    <div id="container">
        <h1> Login </h1>
        <form  action="../DBConnection/loginCheck.php" autocomplete="off" method="POST">
            <table>
                <tr> <td> <label for="username"> Username: </label> </td> <td> <input id="username" type="text" name="username" <?php writeError(); ?> required autofocus> </td> </tr>
                <tr> <td> <label for="password"> Password: </label> </td> <td> <input id="password" type="password" name="password" required> 
                <button id="visBut" type="button" onClick="changeVisibility()"> Mostra </button> </td> </tr>
            </table>
            <input type="submit" value="LOGIN">
        </form>
    
    <?php
        if(isset($_SESSION["error"]) && $_SESSION["error"] == True) {
            echo "<p id=\"error\"> Errore durante l'accesso </p>";
        }
            
    ?>
    </div>
</body>

<?php
    function writeError(){
        if(isset($_SESSION["errorUsername"])) {
            echo "value= \"" . $_SESSION["errorUsername"] . "\"";
        }

        if(isset($_SESSION["error"]) && $_SESSION["error"] == True ) {
            echo "onKeyDown=\"removeError()\"";
        }
        
    }

    session_unset();
    session_destroy();
?>
