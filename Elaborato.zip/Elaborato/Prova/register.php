<?php
session_start();
session_unset();
session_destroy();
?>
<head>
    <?php INCLUDE "../DBConnection/getProvince.php"; ?>
    
    <script src="../Script/changeVisibility.js"> </script>

    <script src="../Script/usernameCheck.js"> </script>

    <script src="../Script/passwordCheck.js"> </script>

    <link rel="stylesheet" type="text/css" href="../Style/forms.css">
</head>

<body onLoad="getComuni();usernameCheck();passwordCheck()">
    <div id="container">
        <h1> Registrati </h1>
        <form action="../DBConnection/addUser.php" autocomplete="off" method="POST">
            <table>
                <tr> <td> <label for="username"> Username: </label> </td> <td> <input id="username" type="text" name="username" required oninput="usernameCheck()"> </td> </tr>
                <tr> <td> <label for="password"> Password: </label> </td> <td> <input id="password" type="password" name="password" required oninput="passwordCheck()"> 
                <button id="visBut" type="button" onClick="changeVisibility()"> Mostra </button> </td> </tr>
                <tr> <td> <label for="mail"> Email: </label> </td> <td><input type="email" name="mail" required> </td> </tr>
            </table> 

            <div id="sesso">
                Sesso: <br>
                <input id="m" type="radio" name="sesso" value="m" required> <label for="m"> Maschio </label> <br>
                <input id="f" type="radio" name="sesso" value="f"> <label for="f"> Femmina </label> <br>
                <input id="o" type="radio" name="sesso" value="o" checked> <label for="o"> Altro </label>  <br>
            </div>

            <table>
                <tr> <td> <label for="anno"> Anno nascita: </label> </td> <td> <input type="number" min="1900" max="2021" value="2021" name="anno" required> </td> </tr>
                <tr> <td> Residenza: </td> 
                <td> <?php getProvince();?>
                <select name='comuni' id="comuni" required> </select> </td> </tr>
            </table>

            <input id="submitButton" type="submit" value="Registrati"> 
        </form>
    
        <div id="checks">
            <p id="vibeCheck"></p>
            <p id="passCheck"></p>
        </div>
    </div>
</body>