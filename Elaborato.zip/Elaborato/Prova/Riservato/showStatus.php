<?php 
    session_start();
    if(!isset($_SESSION["username"])) {
        header("Location: killSession.php");
    }
    INCLUDE "../../DBConnection/getStati.php";
?>
<head>
    <link rel="stylesheet" type="text/css" href="../../Style/utilityButtons.css">
    <link rel="stylesheet" type="text/css" href="../../Style/content.css">
</head>
<body>
    <div id="utilityButtons">
        <a href="killSession.php" id="logoutButton">LOGOUT</a>
        <a href="welcome.php" id="backButton"> INDIETRO </a>
    </div>

    <div id="container">
        <?php
            if(isset($_SESSION["id"])) {
                getStati($_SESSION["id"]);
            }
        ?>
    </div>
</body>
