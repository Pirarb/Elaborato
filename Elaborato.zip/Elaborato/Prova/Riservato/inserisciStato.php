<?php
    session_start();
    if(!isset($_SESSION["username"])) {
        header("Location: killSession.php");
    }

    if(!isset($_SESSION["stato"]) || $_SESSION["stato"] == false) {
        header("Location: welcome.php");
    }

    INCLUDE "../../DBConnection/getParametri.php";
?>

<head>
    <script src="../../Script/sintomi.js">  
    </script>

    <link rel="stylesheet" type="text/css" href="../../Style/utilityButtons.css">
    <link rel="stylesheet" type="text/css" href="../../Style/forms.css">
</head>
<body>
    <div id="utilityButtons">
        <a href="killSession.php" id="logoutButton">LOGOUT</a>
        <a href="welcome.php" id="backButton"> INDIETRO </a>
    </div>

    <div id="container">
        <form action="../../DBConnection/addStato.php" method="POST">
            <h1> Stato </h1>
            <input type="radio" id="positivo" name="positivita" value="1" onclick="getSintomi()">
            <label for="positivo"> Positivo </label> <br>
            <input type="radio" id="negativo" name="positivita" value="0" onclick="clearSintomi()" checked>
            <label for="negativo"> Negativo </label> <br>

            <h1> Misurazioni </h1>
            <?php getParametri() ?>

            <div id="sintomi">
            </div>

            <input type="submit" value="Manda"> 
        </form>
    </div>
</body>
