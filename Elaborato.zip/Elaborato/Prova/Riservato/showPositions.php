<?php 
    session_start();
    if(!isset($_SESSION["username"])) {
        header("Location: killSession.php");
    }
    INCLUDE "../../DBConnection/getPosizioni.php";
?>
<head>
    <link rel="stylesheet" type="text/css" href="../../Style/utilityButtons.css">
    <link rel="stylesheet" type="text/css" href="../../Style/content.css">
    <link rel="stylesheet" type="text/css" href="../../Style/map.css">
    <link rel="stylesheet" type="text/css" href="../../Style/background.css">
    <?php INCLUDE "navbar.php"; ?>

    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css"
   integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A=="
   crossorigin=""/>

   <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"
   integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA=="
   crossorigin=""></script>

    <style>
       .pog {
            text-decoration: none;
            background-color: blue;
            padding: 7px; 
            border-radius: 5px;
       }

       .pog:hover {
            background-color: darkblue;
       }
    </style>
</head>
<body>
<?php printNavbar("showPositions.php"); ?>
    <!--div id="utilityButtons">
        <a href="killSession.php" id="logoutButton">LOGOUT</a>
        <a href="welcome.php" id="backButton"> INDIETRO </a>
    </div-->


        <!--div id="prova"-->
            <div id="containerMappa">
                <div id="map"></div>
            </div>

            <div id="container">
                    <?php
                        if(isset($_SESSION["id"])) {
                            getPosizioni($_SESSION["id"]);
                        }
                    ?>
            </div>
        <!--/div--> 
    
    <script>
        var map = L.map("map");
        L.tileLayer("https://api.maptiler.com/maps/basic/{z}/{x}/{y}.png?key=UaOAVLgfNxf6yuTiIMLq", {
            attribution: '<a href="https://www.maptiler.com/copyright/" target="_blank">&copy; MapTiler</a> <a href="https://www.openstreetmap.org/copyright" target="_blank">&copy; OpenStreetMap contributors</a>',
        }).addTo(map);
        
        <?php getMarker($_SESSION["id"]); ?>
        
        var popup = L.popup();
        function onMapClick(e) {
            //var marker = L.marker([e.latlng.lat, e.latlng.lng]).addTo(map);
            popup.setLatLng(e.latlng).setContent("<div id='popup'>Latitudine: " + e.latlng.lat + "<br>Longitudine: " + e.latlng.lng + "<br><br><a href='../../DBConnection/addPosition.php?lat="+ e.latlng.lat +"&lng="+ e.latlng.lng +"' style='color: white;' class='pog'> Aggiungi </a> </div>").openOn(map);
            //alert("Poggers alert");
        }
        map.on("click", onMapClick);
        //chiave pk.eyJ1IjoidGV0b2xvIiwiYSI6ImNrcTB5bjY2dTAzOG0yd2t3MTI3cWoyZHMifQ.9DzEwVUZXkuc4PF_4ouMbA
   </script>
</body>

