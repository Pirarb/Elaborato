<?php
    session_start();
    if(!isset($_SESSION["username"])) {
        header("Location: killSession.php");
    }
?>
<head>
    <?php INCLUDE "../../DBConnection/controlloData.php"; ?>
    <link rel="stylesheet" type="text/css" href="../../Style/utilityButtons.css">
    <link rel="stylesheet" type="text/css" href="../../Style/content.css">
</head>
<body>
    <div id="utilityButtons">
        <a href="killSession.php" id="logoutButton">LOGOUT</a>
    </div>

    <div id="container">
        <?php 
            if(isset($_SESSION["username"])) {
                echo "<h1> Benvenut";
                if(isset($_SESSION["sesso"])) {
                    switch($_SESSION["sesso"]) {
                        case 'm': echo "o "; break;
                        case 'f': echo "a "; break;
                        default: echo "* "; break;
                    }
                }
                echo $_SESSION["username"] . " </h1>";
            }
        ?>

        <a href="showDatas.php" id="contentButton"> Visualizza dati </a>

        <?php
            if(controlloData($_SESSION["id"]) == true) {
                $_SESSION["stato"] = true;
                echo "<a href=\"inserisciStato.php\" id=\"contentButton\"> Inserisci stato </a>";
            } else {
                $_SESSION["stato"] = false;
            }
        ?>

        <a href="showStatus.php" id="contentButton"> Visualizza stati </a>
        <a href="showPositions.php" id="contentButton"> Visualizza posizioni </a>
    </div>
</body>
