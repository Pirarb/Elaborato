<?php 
/*da includere nell'head delle <pagine></pagine>*/
INCLUDE "../../DBConnection/controlloData.php";
echo '<link rel="stylesheet" type="text/css" href="../../Style/navbar.css">';
function printNavbar($excluded) {
    echo '<ul id="menu">';
    echo '<li> <a href="killSession.php"> Logout </a> </li>';
    if($excluded != "welcome.php") {echo '<li> <a href="welcome.php"> Indietro </a> </li>';}
    //if($excluded != "showDatas.php") {echo '<li> <a href="showDatas.php"> Visualizza dati </a> </li>';}
            
    if(controlloData($_SESSION["id"]) == true ) {
        $_SESSION["stato"] = true;
        if($excluded != "inserisciStato.php") {echo "<li> <a href='inserisciStato.php'> Inserisci stato </a> </li>";}
    } else {
        $_SESSION["stato"] = false;
    }
    
    if($excluded != "showStatus.php") {echo '<li> <a href="showStatus.php"> Visualizza stati </a> </li>';}
    if($excluded != "showPositions.php") {echo '<li> <a href="showPositions.php"> Visualizza posizioni </a> </li>';}
    echo '</ul>';
}


