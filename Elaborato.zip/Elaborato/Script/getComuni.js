function getComuni(id_provincia) {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("comuni").innerHTML = this.responseText;
        }
    };
    xmlhttp.open("GET","../Ajax/getComuni.php?id_provincia="+document.getElementById("province").value,true);
    xmlhttp.send();
}
