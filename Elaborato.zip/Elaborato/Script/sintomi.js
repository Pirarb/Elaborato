function getSintomi() {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("sintomi").innerHTML = this.responseText;
        }
    };
    xmlhttp.open("GET","../../Ajax/getSintomi.php",true); 
    xmlhttp.send();
}

function clearSintomi() {
    document.getElementById("sintomi").innerHTML = "";
}


//essndo chiamata da dentro la sezione riservata abbiamo bisogno di uscire due volte