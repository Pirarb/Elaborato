function getSintomi() {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("sintomi").innerHTML = this.responseText;
            center();
        }
    };
    xmlhttp.open("GET","../../Ajax/getSintomi.php",true); 
    xmlhttp.send();
}

function clearSintomi() {
    document.getElementById("sintomi").innerHTML = "";
    center();
}

function center() {
    var div = document.getElementById("container");
    div.style.top = "50%";
    div.style.left = "50%";
    div.style.transform = "translate(-50%,-30%)";
    //alert("pog");
    //div.style.transform = "translate(x,y)"
}

//essndo chiamata da dentro la sezione riservata abbiamo bisogno di uscire due volte