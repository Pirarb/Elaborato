function changeVisibility() {
    //alert(document.getElementById("password").type);
    var pass = document.getElementById("password");
    var butt = document.getElementById("visBut");
    
    if(pass.type == "password") {
        pass.type = "text";
        butt.innerHTML = "Nascondi";
    } else {
        pass.type = "password";
        butt.innerHTML = "Mostra";
    }

}