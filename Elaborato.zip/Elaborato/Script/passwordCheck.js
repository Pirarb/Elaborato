function passwordCheck() {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("passCheck").innerHTML = this.responseText;

            if(document.getElementById("passCheck").innerHTML === "" && document.getElementById("vibeCheck").innerHTML === "") {
                document.getElementById("submitButton").disabled = false;
                document.getElementById("checks").style.visibility = "hidden";
            } else {
                document.getElementById("submitButton").disabled = true;
                document.getElementById("checks").style.visibility = "visible";
            }
        }
    };
    xmlhttp.open("GET","../Ajax/passwordCheck.php?password="+document.getElementById("password").value,true);
    xmlhttp.send();
}
