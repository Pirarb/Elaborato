function usernameCheck() {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("vibeCheck").innerHTML = this.responseText; 

            if(document.getElementById("vibeCheck").innerHTML === "" && document.getElementById("passCheck").innerHTML === "") { 
                document.getElementById("submitButton").disabled = false;
                document.getElementById("checks").style.visibility = "hidden";
            } else {
                document.getElementById("submitButton").disabled = true;
                document.getElementById("checks").style.visibility = "visible";
            }
        }
    };
    xmlhttp.open("GET","../Ajax/usernameCheck.php?username="+document.getElementById("username").value,true);
    xmlhttp.send();
}

/* non usare vibeCheck ma cercare qualcos'altro. Meglio una p per controllo  */